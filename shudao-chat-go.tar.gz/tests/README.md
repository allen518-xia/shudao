# 健康检查和搜索功能测试

本目录包含了针对 `http://47.109.37.38:5000` 服务的健康检查和搜索功能测试。

## 测试功能

### 1. 健康检查测试 (`TestHealthCheck`)
- **端点**: `GET /health`
- **功能**: 测试服务是否正常运行
- **验证**: 检查响应状态码是否为200，响应内容不为空

### 2. 搜索功能测试 (`TestSearchAPI`)
- **端点**: `POST /search`
- **功能**: 测试搜索API功能
- **请求格式**:
```json
{
  "query": "技术",
  "n_results": 3
}
```
- **验证**: 检查响应状态码、结果数量、搜索结果内容

### 3. 集成测试 (`TestHealthAndSearchIntegration`)
- **功能**: 先执行健康检查，再执行搜索测试
- **用途**: 验证服务的完整工作流程

## 运行测试

### 方法1: 运行所有测试
```bash
cd tests
go test -v
```

### 方法2: 运行特定测试
```bash
# 只运行健康检查测试
go test -v -run TestHealthCheck

# 只运行搜索功能测试
go test -v -run TestSearchAPI

# 只运行集成测试
go test -v -run TestHealthAndSearchIntegration
```

### 方法3: 运行性能测试
```bash
# 健康检查性能测试
go test -bench=BenchmarkHealthCheck

# 搜索API性能测试
go test -bench=BenchmarkSearchAPI
```

## 配置

测试配置在 `config.go` 文件中定义，支持通过环境变量覆盖默认配置：

- `HEALTH_BASE_URL`: 健康检查服务地址 (默认: http://47.109.37.38:5000)
- `SEARCH_BASE_URL`: 搜索服务地址 (默认: http://47.109.37.38:5000)
- `TEST_TIMEOUT`: 测试超时时间，单位秒 (默认: 30)
- `TEST_MAX_RETRIES`: 最大重试次数 (默认: 3)

## 测试用例

### 健康检查测试
- 发送GET请求到 `/health` 端点
- 验证响应状态码为200
- 验证响应内容不为空
- 尝试解析JSON响应（如果适用）

### 搜索功能测试
包含以下测试用例：
1. **技术搜索测试**: 查询"技术"，返回3个结果
2. **编程搜索测试**: 查询"编程"，返回5个结果
3. **AI搜索测试**: 查询"人工智能"，返回2个结果

每个测试用例都会：
- 发送POST请求到 `/search` 端点
- 验证响应状态码为200
- 验证响应内容不为空
- 尝试解析JSON响应
- 显示搜索结果详情

## 预期输出

测试成功时，您将看到类似以下的输出：

```
=== RUN   TestHealthCheck
    TestHealthCheck: api_test.go:xxx: 健康检查响应状态码: 200
    TestHealthCheck: api_test.go:xxx: 响应内容: {"status": "ok"}
    TestHealthCheck: api_test.go:xxx: ✅ 健康检查返回JSON格式响应: map[status:ok]
--- PASS: TestHealthCheck (0.123s)

=== RUN   TestSearchAPI
    TestSearchAPI: api_test.go:xxx: 搜索响应状态码: 200
    TestSearchAPI: api_test.go:xxx: 搜索查询: 技术
    TestSearchAPI: api_test.go:xxx: 请求结果数量: 3
    TestSearchAPI: api_test.go:xxx: ✅ 搜索成功！
    TestSearchAPI: api_test.go:xxx: 查询: 技术
    TestSearchAPI: api_test.go:xxx: 总结果数: 5
    TestSearchAPI: api_test.go:xxx: 返回结果数: 3
--- PASS: TestSearchAPI (0.456s)
```

## 故障排除

如果测试失败，请检查：

1. **网络连接**: 确保能够访问 `http://47.109.37.38:5000`
2. **服务状态**: 确保目标服务正在运行
3. **端点配置**: 验证健康检查和搜索端点是否正确配置
4. **请求格式**: 确认搜索请求的JSON格式是否正确

## 注意事项

- 测试包含超时设置，避免长时间等待
- 搜索测试会尝试解析不同格式的响应
- 如果服务返回非标准格式，测试会记录警告但不会失败
- 性能测试会进行多次请求以测量响应时间 